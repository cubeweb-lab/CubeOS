; stage3.asm - ������ ������� ������ (� TEMP_BUFFER)
bits 16
org 0x8000

; ���������
KERNEL_LBA      equ 34
KERNEL_SECTORS  equ 32
KERNEL_ADDR     equ 0x100000
TEMP_BUFFER     equ 0x2000

start_stage3:
    cli
    mov [boot_drive], dl

    mov ax, 0x0003
    int 0x10

    mov si, msg_stage3
    call print16

    ; ��������� ���� �� ��������� �����
    mov bx, TEMP_BUFFER
    mov cx, KERNEL_SECTORS
    call load_kernel
    jc kernel_error

    mov si, msg_kernel_loaded
    call print16

    ; ��������� GDT
    call load_gdt
    jc gdt_error
    mov si, msg_gdt_ok
    call print16

    ; ������� � Protected Mode
    call enter_protected_mode
    
    jmp halt

print16:
    lodsb
    or al, al
    jz .done
    mov ah, 0x0E
    int 0x10
    jmp print16
.done:
    ret

load_kernel:
    mov si, packet
    mov word [si], 0x10
    mov word [si+2], cx
    mov word [si+4], bx
    mov word [si+6], 0
    mov dword [si+8], KERNEL_LBA
    mov dword [si+12], 0
    
    mov ah, 0x42
    mov dl, [boot_drive]
    int 0x13
    ret

load_gdt:
    lgdt [gdtr]
    clc
    ret

enter_protected_mode:
    mov eax, cr0
    or al, 1
    mov cr0, eax
    jmp 0x08:protected_mode

boot_drive  db 0
packet      times 16 db 0

msg_stage3          db "Stage3: Starting", 0x0D, 0x0A, 0
msg_kernel_loaded   db "  Kernel loaded", 0x0D, 0x0A, 0
msg_gdt_ok          db "  GDT loaded", 0x0D, 0x0A, 0

kernel_error:
    mov si, msg_kernel_error
    call print16
    jmp halt

gdt_error:
    mov si, msg_gdt_error
    call print16

halt:
    cli
    hlt

msg_kernel_error db "ERROR: Kernel load failed!", 0x0D, 0x0A, 0
msg_gdt_error    db "ERROR: GDT failed!", 0x0D, 0x0A, 0

; GDT
align 8
gdt:
    dq 0x0000000000000000
    dq 0x00CF9A000000FFFF
    dq 0x00CF92000000FFFF
    dq 0x00209A0000000000
gdt_end:

gdtr:
    dw gdt_end - gdt - 1
    dd gdt

; 32-bit Protected Mode
bits 32
protected_mode:
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax
    mov esp, 0x90000

    ; Paging setup
    mov edi, 0x91000
    mov ecx, 0x3000 / 4
    xor eax, eax
    rep stosd
    
    mov dword [0x91000], 0x92000 | 0x03
    mov dword [0x92000], 0x93000 | 0x03
    
    mov edi, 0x93000
    mov ebx, 0
    mov ecx, 512
.map_pages:
    mov eax, ebx
    or eax, 0x83
    mov dword [edi], eax
    add ebx, 0x200000
    add edi, 8
    loop .map_pages
    
    mov eax, 0x91000
    mov cr3, eax
    mov eax, cr4
    or eax, 0x20
    mov cr4, eax
    mov ecx, 0xC0000080
    rdmsr
    or eax, 0x100
    wrmsr
    mov eax, cr0
    or eax, 0x80000000
    mov cr0, eax
    
    jmp 0x18:long_mode

; 64-bit Long Mode
bits 64
long_mode:
    xor rax, rax
    mov ss, ax
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov rsp, 0x800000

    ; �������� ���� �� ���������� ������
    mov rsi, TEMP_BUFFER
    mov rdi, KERNEL_ADDR
    mov rcx, (KERNEL_SECTORS * 512) / 8
    rep movsq

    jmp KERNEL_ADDR