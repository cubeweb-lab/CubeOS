﻿; stage1.asm - Первичный загрузчик (MBR, 512 байт)
bits 16
org 0x7C00

start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    sti

    mov [boot_drive], dl

    mov ax, 0x0003
    int 0x10

    mov si, msg_stage1
    call print

    mov bx, 0x7E00
    mov al, 32
    mov ch, 0
    mov cl, 2
    mov dh, 0
    mov dl, [boot_drive]
    mov ah, 0x02
    int 0x13
    jc disk_error

    mov si, msg_ok
    call print

    mov dl, [boot_drive]
    jmp 0x0000:0x7E00

disk_error:
    mov si, err_msg
    call print
    cli
    hlt

print:
    lodsb
    or al, al
    jz .done
    mov ah, 0x0E
    int 0x10
    jmp print
.done:
    ret

boot_drive    db 0
msg_stage1    db "Stage1: OK", 0x0D, 0x0A, 0
msg_ok        db "  -> Stage2", 0x0D, 0x0A, 0
err_msg       db "ERROR!", 0x0D, 0x0A, 0

times 510-($-$$) db 0
dw 0xAA55