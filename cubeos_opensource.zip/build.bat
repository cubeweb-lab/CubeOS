﻿@echo off
echo Building CubeOS...

if not exist "build" mkdir build

nasm -f bin stage1.asm -o build\stage1.bin
nasm -f bin stage2.asm -o build\stage2.bin
nasm -f bin stage3.asm -o build\stage3.bin
nasm -f bin kernel.asm -o build\kernel.bin

powershell -Command "$f = [System.IO.File]::Create('build\cubeos.img'); $f.SetLength(20971520); $f.Close()"

powershell -Command "$b=[System.IO.File]::ReadAllBytes('build\stage1.bin'); $f=[System.IO.File]::OpenWrite('build\cubeos.img'); $f.Write($b,0,$b.Length); $f.Close()"
powershell -Command "$b=[System.IO.File]::ReadAllBytes('build\stage2.bin'); $f=[System.IO.File]::OpenWrite('build\cubeos.img'); $f.Seek(512,0); $f.Write($b,0,$b.Length); $f.Close()"
powershell -Command "$b=[System.IO.File]::ReadAllBytes('build\stage3.bin'); $f=[System.IO.File]::OpenWrite('build\cubeos.img'); $f.Seek(2*512,0); $f.Write($b,0,$b.Length); $f.Close()"
powershell -Command "$b=[System.IO.File]::ReadAllBytes('build\kernel.bin'); $f=[System.IO.File]::OpenWrite('build\cubeos.img'); $f.Seek(34*512,0); $f.Write($b,0,$b.Length); $f.Close()"

powershell -Command "$f = [System.IO.File]::Create('build\data.img'); $f.SetLength(10485760); $f.Close()"

echo.
echo ========================================
echo         BUILD COMPLETE!
echo ========================================
echo.
echo qemu-system-x86_64 -drive format=raw,file=build\cubeos.img -m 128M
echo.
pause