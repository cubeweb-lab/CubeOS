﻿; stage2.asm - Вторичный загрузчик
bits 16
org 0x7E00

STAGE3_LBA      equ 2
STAGE3_SECTORS  equ 32
STAGE3_ADDR     equ 0x8000

start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7E00
    sti

    mov [boot_drive], dl

    mov si, msg_stage2
    call print16

    ; Включаем A20
    in al, 0x92
    test al, 2
    jnz .a20_on
    or al, 2
    out 0x92, al
.a20_on:

    ; Загружаем stage3
    mov bx, STAGE3_ADDR
    mov cx, STAGE3_SECTORS
    mov si, packet
    mov word [si], 0x10
    mov word [si+2], cx
    mov word [si+4], bx
    mov word [si+6], 0
    mov dword [si+8], STAGE3_LBA
    mov dword [si+12], 0
    
    mov ah, 0x42
    mov dl, [boot_drive]
    int 0x13
    jc load_error

    mov si, msg_ok
    call print16

    mov dl, [boot_drive]
    jmp STAGE3_ADDR

print16:
    lodsb
    or al, al
    jz .done
    mov ah, 0x0E
    int 0x10
    jmp print16
.done:
    ret

load_error:
    mov si, msg_load_error
    call print16
    cli
    hlt

boot_drive  db 0
packet      times 16 db 0

msg_stage2      db "Stage2: OK", 0x0D, 0x0A, 0
msg_ok          db "  -> Stage3", 0x0D, 0x0A, 0
msg_load_error  db "ERROR: Stage3 load failed!", 0x0D, 0x0A, 0

times 510-($-$$) db 0
dw 0xAA55