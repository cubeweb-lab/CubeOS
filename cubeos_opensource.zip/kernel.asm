; kernel.asm - CubeOS v0.6 (ATA + FAT32 чтение)
bits 64
org 0x100000

; ------------------------------------------------------------
; СТАРТ
; ------------------------------------------------------------
start:
    call init_system
    call clear_screen
    call print_banner
    call shell_loop

; ------------------------------------------------------------
; ИНИЦИАЛИЗАЦИЯ
; ------------------------------------------------------------
init_system:
    push rax
    mov qword [ticks], 0
    mov byte [current_color], 0x0A
    mov qword [gui_active], 0
    mov word [window_x], 10
    mov word [window_y], 5
    pop rax
    ret

; ------------------------------------------------------------
; ВЫВОД НА ЭКРАН (без изменений)
; ------------------------------------------------------------
clear_screen:
    push rax
    push rcx
    push rdi
    mov rdi, 0xB8000
    mov al, [current_color]
    mov ah, al
    mov al, ' '
    mov rcx, 80*25
    rep stosw
    mov qword [cursor_pos], 0xB8000
    pop rdi
    pop rcx
    pop rax
    ret

print:
    push rax
    push rcx
    push rdx
    push rdi
    push rsi
    mov rdi, [cursor_pos]
    mov ah, 0x0F
.p_loop:
    lodsb
    cmp al, 0
    je .p_done
    cmp al, 0x0A
    je .newline
    stosw
    add qword [cursor_pos], 2
    jmp .p_loop
.newline:
    mov rax, [cursor_pos]
    sub rax, 0xB8000
    shr rax, 1
    mov rcx, 80
    xor rdx, rdx
    div rcx
    inc rax
    mul rcx
    shl rax, 1
    add rax, 0xB8000
    mov [cursor_pos], rax
    mov rdi, rax
    jmp .p_loop
.p_done:
    pop rsi
    pop rdi
    pop rdx
    pop rcx
    pop rax
    ret

print_green:
    push rax
    push rcx
    push rdx
    push rdi
    push rsi
    mov rdi, [cursor_pos]
    mov ah, 0x0A
.p_loop_g:
    lodsb
    cmp al, 0
    je .p_done_g
    cmp al, 0x0A
    je .newline_g
    stosw
    add qword [cursor_pos], 2
    jmp .p_loop_g
.newline_g:
    mov rax, [cursor_pos]
    sub rax, 0xB8000
    shr rax, 1
    mov rcx, 80
    xor rdx, rdx
    div rcx
    inc rax
    mul rcx
    shl rax, 1
    add rax, 0xB8000
    mov [cursor_pos], rax
    mov rdi, rax
    jmp .p_loop_g
.p_done_g:
    pop rsi
    pop rdi
    pop rdx
    pop rcx
    pop rax
    ret

print_number:
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    mov rsi, num_buffer
    add rsi, 10
    mov byte [rsi], 0
    dec rsi
    mov rbx, 10
    mov rcx, 0
.div_loop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    mov [rsi], dl
    dec rsi
    inc rcx
    test rax, rax
    jnz .div_loop
    inc rsi
    mov al, [current_color]
    call print_color
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax
    ret

print_color:
    push rax
    push rcx
    push rdx
    push rdi
    push rsi
    mov rdi, [cursor_pos]
    mov ah, al
.p_loop_c:
    lodsb
    cmp al, 0
    je .p_done_c
    cmp al, 0x0A
    je .newline_c
    stosw
    add qword [cursor_pos], 2
    jmp .p_loop_c
.newline_c:
    mov rax, [cursor_pos]
    sub rax, 0xB8000
    shr rax, 1
    mov rcx, 80
    xor rdx, rdx
    div rcx
    inc rax
    mul rcx
    shl rax, 1
    add rax, 0xB8000
    mov [cursor_pos], rax
    mov rdi, rax
    jmp .p_loop_c
.p_done_c:
    pop rsi
    pop rdi
    pop rdx
    pop rcx
    pop rax
    ret

print_newline:
    push rax
    mov rsi, newline_str
    call print
    pop rax
    ret

print_banner:
    push rsi
    mov rsi, banner1
    call print_green
    mov rsi, banner2
    call print_green
    mov rsi, banner3
    call print_green
    mov rsi, banner4
    call print_green
    pop rsi
    ret

; ------------------------------------------------------------
; ATA PIO ДРАЙВЕР (чтение одного сектора по LBA28)
; ------------------------------------------------------------
ATA_PORT_DATA      equ 0x1F0
ATA_PORT_SECTORS   equ 0x1F2
ATA_PORT_LBA_LOW   equ 0x1F3
ATA_PORT_LBA_MID   equ 0x1F4
ATA_PORT_LBA_HIGH  equ 0x1F5
ATA_PORT_DRIVE     equ 0x1F6
ATA_PORT_COMMAND   equ 0x1F7
ATA_PORT_STATUS    equ 0x1F7

ATA_CMD_READ       equ 0x20

ata_wait:
    push rax
    push rcx
    mov rcx, 10000
.wait:
    in al, ATA_PORT_STATUS
    test al, 0x80      ; BSY?
    jz .ready
    loop .wait
.ready:
    pop rcx
    pop rax
    ret

; Чтение одного сектора
; IN:  RAX = LBA (28 бит), RDI = буфер (512 байт)
ata_read_sector:
    push rax
    push rbx
    push rcx
    push rdx
    push rdi

    call ata_wait

    ; выбрать диск (Master, LBA28)
    mov dx, ATA_PORT_DRIVE
    mov al, 0xE0
    out dx, al

    call ata_wait

    ; кол-во секторов = 1
    mov dx, ATA_PORT_SECTORS
    mov al, 1
    out dx, al

    ; LBA (7:0)
    mov dx, ATA_PORT_LBA_LOW
    mov al, al
    out dx, al

    ; LBA (15:8)
    mov dx, ATA_PORT_LBA_MID
    shr rax, 8
    out dx, al

    ; LBA (23:16)
    mov dx, ATA_PORT_LBA_HIGH
    shr rax, 16
    out dx, al

    ; команда READ
    mov dx, ATA_PORT_COMMAND
    mov al, ATA_CMD_READ
    out dx, al

    call ata_wait

    ; чтение 256 слов (512 байт)
    mov rcx, 256
    mov dx, ATA_PORT_DATA
.read_loop:
    in ax, dx
    stosw
    loop .read_loop

    pop rdi
    pop rdx
    pop rcx
    pop rbx
    pop rax
    ret

; ------------------------------------------------------------
; FAT32 ПАРСЕР (только чтение корневого каталога)
; ------------------------------------------------------------
fat32_bytes_per_sec   dw 0
fat32_sec_per_clust   db 0
fat32_reserved_sec    dw 0
fat32_root_cluster    dd 0

fat32_buffer          times 512 db 0
fat32_name            times 12 db 0

fat32_init:
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi

    mov rsi, msg_fat32_init
    call print

    ; читаем BPB (сектор 0)
    mov rdi, fat32_buffer
    xor rax, rax
    call ata_read_sector
    jc .err

    ; сигнатура 0xAA55
    mov ax, [fat32_buffer + 0x1FE]
    cmp ax, 0xAA55
    jne .err

    ; читаем параметры
    mov ax, [fat32_buffer + 0x0B]
    mov [fat32_bytes_per_sec], ax

    mov al, [fat32_buffer + 0x0D]
    mov [fat32_sec_per_clust], al

    mov ax, [fat32_buffer + 0x0E]
    mov [fat32_reserved_sec], ax

    mov eax, [fat32_buffer + 0x2C]
    mov [fat32_root_cluster], eax

    mov rsi, msg_fat32_ok
    call print
    call print_newline
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax
    clc
    ret
.err:
    mov rsi, msg_fat32_error
    call print
    call print_newline
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax
    stc
    ret

; показать содержимое корневого каталога (первые 16 записей)
fat32_dir:
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi

    mov rsi, msg_dir_header
    call print

    ; TODO: по-хорошему надо читать кластер по цепочке,
    ; но для простоты пока читаем один кластер (с LBA = 100)
    ; Это временно, чтобы увидеть хоть что-то.
    mov rdi, fat32_buffer
    mov rax, 100
    call ata_read_sector
    jc .err

    mov rsi, fat32_buffer
    mov rcx, 16
.next:
    cmp byte [rsi], 0x00
    je .done
    cmp byte [rsi], 0xE5
    je .skip

    ; вывод имени (11 байт)
    push rcx
    push rsi
    mov rdi, fat32_name
    mov rcx, 11
.copy:
    mov al, [rsi]
    cmp al, ' '
    je .space
    stosb
    jmp .next_char
.space:
    mov al, ' '
    stosb
.next_char:
    inc rsi
    loop .copy
    mov byte [rdi], 0
    pop rsi
    pop rcx

    push rcx
    push rsi
    mov rsi, fat32_name
    call print
    mov rsi, spaces
    call print
    pop rsi
    pop rcx
.skip:
    add rsi, 32
    loop .next
.done:
    call print_newline
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax
    ret
.err:
    mov rsi, msg_dir_error
    call print
    call print_newline
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax
    ret

; ------------------------------------------------------------
; ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ (случайные числа и пр.)
; ------------------------------------------------------------
random:
    push rcx
    push rdx
    rdtsc
    pop rdx
    pop rcx
    ret

; ------------------------------------------------------------
; NEOFETCH
; ------------------------------------------------------------
neofetch:
    push rsi
    mov rsi, logo_line1
    call print_green
    mov rsi, logo_line2
    call print_green
    mov rsi, logo_line3
    call print_green
    mov rsi, logo_line4
    call print_green
    mov rsi, logo_line5
    call print_green
    mov rsi, logo_line6
    call print_green
    mov rsi, logo_line7
    call print_green
    mov rsi, logo_line8
    call print_green
    mov rsi, logo_line9
    call print_green
    mov rsi, logo_line10
    call print_green
    mov rsi, info_line1
    call print
    mov rsi, info_line2
    call print
    mov rsi, info_line3
    call print
    mov rsi, info_line4
    call print
    mov rsi, info_line5
    call print
    mov rsi, info_line6
    call print
    pop rsi
    ret

; ------------------------------------------------------------
; GUI (без изменений — рабочий)
; ------------------------------------------------------------
gui_main:
    call gui_save_screen
    call gui_clear
    call gui_draw_desktop
    call gui_draw_window
.gui_loop:
    call gui_handle_input
    cmp qword [gui_active], 0
    je .gui_exit
    jmp .gui_loop
.gui_exit:
    call gui_restore_screen
    ret

gui_save_screen:
    push rsi
    push rdi
    push rcx
    mov rsi, 0xB8000
    mov rdi, screen_buffer
    mov rcx, 80*25
    rep movsw
    pop rcx
    pop rdi
    pop rsi
    ret

gui_restore_screen:
    push rsi
    push rdi
    push rcx
    mov rsi, screen_buffer
    mov rdi, 0xB8000
    mov rcx, 80*25
    rep movsw
    pop rcx
    pop rdi
    pop rsi
    ret

gui_clear:
    push rdi
    push rcx
    mov rdi, 0xB8000
    mov rax, 0x1020102010201020
    mov rcx, 80*25/4
    rep stosq
    pop rcx
    pop rdi
    ret

gui_draw_desktop:
    push rdi
    push rsi
    push rcx
    mov rdi, 0xB8000 + 80*24*2
    mov rax, 0x7020702070207020
    mov rcx, 80/4
    rep stosq
    mov rdi, 0xB8000 + 80*24*2 + 2
    mov rsi, start_btn
    mov ah, 0x70
    call gui_draw_text
    mov rdi, 0xB8000 + 80*2*2 + 4
    mov rsi, icon_shell
    mov ah, 0x0F
    call gui_draw_text
    mov rdi, 0xB8000 + 80*4*2 + 4
    mov rsi, icon_about
    mov ah, 0x0F
    call gui_draw_text
    pop rcx
    pop rsi
    pop rdi
    ret

gui_draw_window:
    push rdi
    push rsi
    push rcx
    push rax
    push rbx
    movzx rax, word [window_x]
    movzx rbx, word [window_y]
    shl rax, 1
    shl rbx, 1
    mov rdi, 0xB8000
    mov rdx, 80*2
    mul rdx
    add rdi, rax
    mov rax, rbx
    add rdi, rax
    mov rcx, 7
.clear_win:
    push rcx
    push rdi
    mov rcx, 30
    mov ax, 0x1F20
    rep stosw
    pop rdi
    add rdi, 80*2
    pop rcx
    loop .clear_win
    movzx rax, word [window_x]
    movzx rbx, word [window_y]
    shl rax, 1
    shl rbx, 1
    mov rdi, 0xB8000
    mov rdx, 80*2
    mul rdx
    add rdi, rax
    mov rax, rbx
    add rdi, rax
    mov rsi, top_frame
    mov ah, 0x1F
    call gui_draw_text
    add rdi, 80*2
    mov rsi, title_line
    call gui_draw_text
    mov rdi, 0xB8000
    movzx rax, word [window_x]
    movzx rbx, word [window_y]
    shl rax, 1
    shl rbx, 1
    mov rdx, 80*2
    mul rdx
    add rdi, rax
    mov rax, rbx
    add rdi, rax
    add rdi, 28*2
    mov rsi, close_btn
    mov ah, 0x4C
    call gui_draw_text
    add rdi, 80*2
    mov rsi, line1
    call gui_draw_text
    add rdi, 80*2
    mov rsi, line2
    call gui_draw_text
    add rdi, 80*2
    mov rsi, line3
    call gui_draw_text
    add rdi, 80*2
    mov rsi, line4
    call gui_draw_text
    pop rbx
    pop rax
    pop rcx
    pop rsi
    pop rdi
    ret

gui_draw_text:
    push rax
.loop:
    lodsb
    cmp al, 0
    je .done
    stosw
    jmp .loop
.done:
    pop rax
    ret

gui_handle_input:
    in al, 0x64
    test al, 1
    jz .no_key
    in al, 0x60
    cmp al, 0x80
    jae .no_key
    cmp al, 0x01
    je .exit_gui
    cmp al, 0x48
    je .move_up
    cmp al, 0x50
    je .move_down
    cmp al, 0x4B
    je .move_left
    cmp al, 0x4D
    je .move_right
    ret
.move_up:
    cmp word [window_y], 1
    jle .no_move
    dec word [window_y]
    call gui_draw_window
    ret
.move_down:
    cmp word [window_y], 17
    jge .no_move
    inc word [window_y]
    call gui_draw_window
    ret
.move_left:
    cmp word [window_x], 1
    jle .no_move
    dec word [window_x]
    call gui_draw_window
    ret
.move_right:
    cmp word [window_x], 49
    jge .no_move
    inc word [window_x]
    call gui_draw_window
    ret
.exit_gui:
    mov qword [gui_active], 0
    ret
.no_move:
    ret
.no_key:
    ret

; ------------------------------------------------------------
; ШЕЛЛ (команды + обработка)
; ------------------------------------------------------------
shell_loop:
    inc qword [ticks]
    push rsi
    mov rsi, prompt
    call print_green
    call read_command
    mov rsi, input_buffer

    mov rdi, cmd_cls       ; cls
    call strcmp
    cmp rax, 1
    je .cmd_cls

    mov rdi, cmd_help
    call strcmp
    cmp rax, 1
    je .cmd_help

    mov rdi, cmd_ver
    call strcmp
    cmp rax, 1
    je .cmd_ver

    mov rdi, cmd_about
    call strcmp
    cmp rax, 1
    je .cmd_about

    mov rdi, cmd_reboot
    call strcmp
    cmp rax, 1
    je .cmd_reboot

    mov rdi, cmd_shutdown
    call strcmp
    cmp rax, 1
    je .cmd_shutdown

    mov rdi, cmd_uptime
    call strcmp
    cmp rax, 1
    je .cmd_uptime

    mov rdi, cmd_mem
    call strcmp
    cmp rax, 1
    je .cmd_mem

    mov rdi, cmd_cpu
    call strcmp
    cmp rax, 1
    je .cmd_cpu

    mov rdi, cmd_dice
    call strcmp
    cmp rax, 1
    je .cmd_dice

    mov rdi, cmd_flip
    call strcmp
    cmp rax, 1
    je .cmd_flip

    mov rdi, cmd_gui
    call strcmp
    cmp rax, 1
    je .cmd_gui

    mov rdi, cmd_fat32
    call strcmp
    cmp rax, 1
    je .cmd_fat32

    mov rdi, cmd_dir
    call strcmp
    cmp rax, 1
    je .cmd_dir

    cmp byte [input_buffer], 0
    je .done

    mov rsi, msg_unknown
    call print
    jmp .done

.cmd_cls:
    call clear_screen
    call print_banner
    jmp .done
.cmd_help:
    mov rsi, msg_help
    call print_green
    jmp .done
.cmd_ver:
    mov rsi, msg_version
    call print
    jmp .done
.cmd_about:
    call clear_screen
    call neofetch
    jmp .done
.cmd_reboot:
    mov rsi, msg_reboot
    call print
    cli
    hlt
.cmd_shutdown:
    mov rsi, msg_shutdown
    call print
    mov al, 0xFE
    out 0x64, al
    cli
    hlt
.cmd_uptime:
    mov rsi, uptime_msg
    call print
    mov rax, [ticks]
    call print_number
    mov rsi, ticks_msg
    call print
    jmp .done
.cmd_mem:
    mov rsi, mem_msg
    call print
    jmp .done
.cmd_cpu:
    mov rsi, cpu_msg
    call print
    jmp .done
.cmd_dice:
    call random
    mov rdx, 0
    mov rbx, 6
    div rbx
    inc rdx
    mov rsi, dice_msg
    call print
    mov rax, rdx
    call print_number
    jmp .done
.cmd_flip:
    call random
    test rax, 1
    jz .flip_tails
    mov rsi, flip_heads
    call print
    jmp .done
.flip_tails:
    mov rsi, flip_tails_msg
    call print
    jmp .done
.cmd_gui:
    mov qword [gui_active], 1
    call gui_main
    call clear_screen
    call print_banner
    jmp .done
.cmd_fat32:
    call fat32_init
    jmp .done
.cmd_dir:
    call fat32_dir
    jmp .done

.done:
    pop rsi
    jmp shell_loop

; ------------------------------------------------------------
; ВВОД КОМАНД (клавиатура, backspace, enter)
; ------------------------------------------------------------
read_command:
    push rdi
    push rcx
    push rax
    mov rdi, input_buffer
    xor rcx, rcx
.read_char:
    call get_key
    cmp al, 0
    je .read_char
    cmp al, 0x0D
    je .enter
    cmp al, 0x08
    je .backspace
    mov [rdi], al
    inc rdi
    inc rcx
    push rdi
    mov rdi, [cursor_pos]
    mov ah, [current_color]
    stosw
    add qword [cursor_pos], 2
    pop rdi
    jmp .read_char
.backspace:
    cmp rcx, 0
    je .read_char
    dec rdi
    dec rcx
    push rdi
    sub qword [cursor_pos], 2
    mov rdi, [cursor_pos]
    mov ah, [current_color]
    mov al, ' '
    stosw
    pop rdi
    jmp .read_char
.enter:
    mov byte [rdi], 0
    mov rax, [cursor_pos]
    sub rax, 0xB8000
    shr rax, 1
    mov rcx, 80
    xor rdx, rdx
    div rcx
    inc rax
    mul rcx
    shl rax, 1
    add rax, 0xB8000
    mov [cursor_pos], rax
    pop rax
    pop rcx
    pop rdi
    ret

; ------------------------------------------------------------
; КЛАВИАТУРА (скан-коды → ASCII)
; ------------------------------------------------------------
get_key:
    in al, 0x64
    test al, 1
    jz get_key
    in al, 0x60
    cmp al, 0x80
    jae get_key

    cmp al, 0x02
    je .1
    cmp al, 0x03
    je .2
    cmp al, 0x04
    je .3
    cmp al, 0x05
    je .4
    cmp al, 0x06
    je .5
    cmp al, 0x07
    je .6
    cmp al, 0x08
    je .7
    cmp al, 0x09
    je .8
    cmp al, 0x0A
    je .9
    cmp al, 0x0B
    je .0

    cmp al, 0x1E
    je .a
    cmp al, 0x30
    je .b
    cmp al, 0x2E
    je .c
    cmp al, 0x20
    je .d
    cmp al, 0x12
    je .e
    cmp al, 0x21
    je .f
    cmp al, 0x22
    je .g
    cmp al, 0x23
    je .h
    cmp al, 0x17
    je .i
    cmp al, 0x24
    je .j
    cmp al, 0x25
    je .k
    cmp al, 0x26
    je .l
    cmp al, 0x32
    je .m
    cmp al, 0x31
    je .n
    cmp al, 0x18
    je .o
    cmp al, 0x19
    je .p
    cmp al, 0x10
    je .q
    cmp al, 0x13
    je .r
    cmp al, 0x1F
    je .s
    cmp al, 0x14
    je .t
    cmp al, 0x16
    je .u
    cmp al, 0x2F
    je .v
    cmp al, 0x11
    je .w
    cmp al, 0x2D
    je .x
    cmp al, 0x15
    je .y
    cmp al, 0x2C
    je .z

    cmp al, 0x1C
    je .enter
    cmp al, 0x0E
    je .back
    cmp al, 0x39
    je .space

    mov al, 0
    ret

.0: mov al, '0'  ; 0x0B
    ret
.1: mov al, '1'  ; 0x02
    ret
.2: mov al, '2'  ; 0x03
    ret
.3: mov al, '3'  ; 0x04
    ret
.4: mov al, '4'  ; 0x05
    ret
.5: mov al, '5'  ; 0x06
    ret
.6: mov al, '6'  ; 0x07
    ret
.7: mov al, '7'  ; 0x08
    ret
.8: mov al, '8'  ; 0x09
    ret
.9: mov al, '9'  ; 0x0A
    ret
.enter:     mov al, 0x0D
    ret
.back:      mov al, 0x08
    ret
.space:     mov al, ' '
    ret
.a: mov al, 'a'
    ret
.b: mov al, 'b'
    ret
.c: mov al, 'c'
    ret
.d: mov al, 'd'
    ret
.e: mov al, 'e'
    ret
.f: mov al, 'f'
    ret
.g: mov al, 'g'
    ret
.h: mov al, 'h'
    ret
.i: mov al, 'i'
    ret
.j: mov al, 'j'
    ret
.k: mov al, 'k'
    ret
.l: mov al, 'l'
    ret
.m: mov al, 'm'
    ret
.n: mov al, 'n'
    ret
.o: mov al, 'o'
    ret
.p: mov al, 'p'
    ret
.q: mov al, 'q'
    ret
.r: mov al, 'r'
    ret
.s: mov al, 's'
    ret
.t: mov al, 't'
    ret
.u: mov al, 'u'
    ret
.v: mov al, 'v'
    ret
.w: mov al, 'w'
    ret
.x: mov al, 'x'
    ret
.y: mov al, 'y'
    ret
.z: mov al, 'z'
    ret

; ------------------------------------------------------------
; СРАВНЕНИЕ СТРОК
; ------------------------------------------------------------
strcmp:
    push rsi
    push rdi
    push rcx
    xor rcx, rcx
.loop:
    mov al, [rsi+rcx]
    mov bl, [rdi+rcx]
    cmp al, bl
    jne .not_equal
    cmp al, 0
    je .equal
    inc rcx
    jmp .loop
.not_equal:
    mov rax, 0
    jmp .done
.equal:
    mov rax, 1
.done:
    pop rcx
    pop rdi
    pop rsi
    ret

; ------------------------------------------------------------
; ДАННЫЕ
; ------------------------------------------------------------
cursor_pos          dq 0xB8000
ticks               dq 0
current_color       db 0x0A
gui_active          dq 0
input_buffer        times 64 db 0
num_buffer          times 16 db 0
window_x            dw 10
window_y            dw 5
screen_buffer       times 80*25*2 db 0

cmd_cls         db "cls", 0
cmd_help        db "help", 0
cmd_ver         db "ver", 0
cmd_about       db "about", 0
cmd_reboot      db "reboot", 0
cmd_shutdown    db "shutdown", 0
cmd_uptime      db "uptime", 0
cmd_mem         db "mem", 0
cmd_cpu         db "cpu", 0
cmd_dice        db "dice", 0
cmd_flip        db "flip", 0
cmd_gui         db "gui", 0
cmd_fat32       db "fat32", 0
cmd_dir         db "dir", 0

banner1 db "==============================", 0x0A, 0
banner2 db "     CubeOS v0.6 (ATA+FAT32)  ", 0x0A, 0
banner3 db "    Copyright (c) 2026 CubeDev  ", 0x0A, 0
banner4 db "==============================", 0x0A, 0

logo_line1  db "       +--------------+", 0x0A, 0
logo_line2  db "      /              /|", 0x0A, 0
logo_line3  db "     /              / |", 0x0A, 0
logo_line4  db "    +--------------+  |", 0x0A, 0
logo_line5  db "    |              |  |", 0x0A, 0
logo_line6  db "    |   CUBEOS     |  |", 0x0A, 0
logo_line7  db "    |              |  |", 0x0A, 0
logo_line8  db "    |              |  +", 0x0A, 0
logo_line9  db "    |              | /", 0x0A, 0
logo_line10 db "    +--------------+", 0x0A, 0

info_line1  db "   ", 0x0A, 0
info_line2  db "   OS: CubeOS v0.6 (64-bit + ATA)", 0x0A, 0
info_line3  db "   Shell: CubeOS Shell v6", 0x0A, 0
info_line4  db "   CPU: x86_64 (Long Mode)", 0x0A, 0
info_line5  db "   Memory: 128 MB (QEMU)", 0x0A, 0
info_line6  db "   Bootloader: 3-stage (NASM)", 0x0A, 0

prompt      db "cubeos> ", 0
msg_help    db "Commands: cls, help, ver, about, reboot, shutdown, uptime, mem, cpu, dice, flip, gui, fat32, dir", 0x0A, 0
msg_version db "CubeOS version 0.6 (64-bit) + ATA + FAT32", 0x0A, 0
msg_unknown db "Unknown command. Type 'help'", 0x0A, 0
msg_reboot  db "Rebooting...", 0x0A, 0
msg_shutdown db "Shutting down...", 0x0A, 0
uptime_msg  db "Uptime: ", 0
ticks_msg   db " ticks", 0x0A, 0
mem_msg     db "Memory: 128 MB (QEMU)", 0x0A, 0
cpu_msg     db "CPU: x86_64 with Long Mode support", 0x0A, 0
dice_msg    db "Dice roll: ", 0
flip_heads  db "Heads!", 0x0A, 0
flip_tails_msg db "Tails!", 0x0A, 0
newline_str db 0x0A, 0
spaces      db "  ", 0

; GUI строки
start_btn      db "[ START ]", 0
close_btn      db "[X]", 0
top_frame      db "+------------------------------+", 0
title_line     db "| CubeOS Shell                  |", 0
line1          db "|                              |", 0
line2          db "|  Welcome to CubeOS GUI!      |", 0
line3          db "|  Use arrow keys to move      |", 0
line4          db "|  Press ESC to exit           |", 0
icon_shell     db "[*] Cube Shell", 0
icon_about     db "[i] About", 0

; FAT32 сообщения
msg_fat32_init      db "FAT32: Initializing... ", 0
msg_fat32_ok        db "OK", 0x0A, 0
msg_fat32_error     db "ERROR", 0x0A, 0
msg_dir_header      db "Directory of /:", 0x0A, 0
msg_dir_error       db "ERROR: cannot read directory", 0x0A, 0